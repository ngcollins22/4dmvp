/*

    4DMVP Project for Collins Aerospace
    Author: Nathan Collins
    Date Created: 8/18/24
    Last Updated: 11/24/24
*/

#include "pathfind.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

const int pace = 3; //maximum random increase in path request time for each monte carlo sub-iteration

void monteCarloIteration(int charLength, int charHeight, int maxIter) {
    //function that runs a map until a max iteration count or failure
    //demonstrates how the algorithm is used:
    map_t *map = emptyMap(charLength, charLength, charHeight, 1); //allocate the map
    FILE* tensorOut = fopen("tensor.csv", "w"); //open a file to record the tensor after run is done
    FILE* shortPathInfo = fopen("paths.csv","w"); //open a file to record stats on each path 
    fprintf(shortPathInfo, "ID, IdealT0, H0, Gf, TTS (ms)\n");
    printf("Monte Carlo Iteration Start: (%dX%dX%d) \n", charLength, charLength, charHeight);
    vehicle_t vehicle = { //define a vehicle performance profile to use
        .hdot = 1,
        .psidot = 0.1,
        .R = 2,
        .vdot = 0.05,
        .vpref = 2,
        .vstall = 1
    };
    int tau_randomizer = 0; //an initial "request time" counter used to space out path requests.
    for(int i = 0; i < maxIter; i++) { //loop until max iterations hit
        printf("Iteration #%d\n", i+1);
        srand(clock());
        path_t *path = (path_t*)calloc(1,sizeof(path_t));
        path->vehicle = vehicle;
        path->ideal_tau_start = tau_randomizer;
        tau_randomizer += rand() % pace; //increment the next path request time by a random number
        int z = 5; //all vehicles start/end at an identical height (as they would in real life)
        point_t start = {.x = rand() % charLength, .y = rand() % charLength, .z = z}; //create random start and end coordinates
        point_t end = {.x = rand() % charLength, .y = rand() % charLength, .z = z};
        path->startPoint = start; //add the start and end coordinates to the path
        path->endPoint = end;
        pathFind(map, path); //call the main pathfinding algorithm
        if(path->solved == -1) { //monte carlo exits at first failure - algorithm should not fail unless there's an error.
            printf("Path #%d failed to solve. Monte Carlo exiting.\n", path->id);
            //exportPathShort(shortPathInfo, path);
            //exportPathShort(statFile, path);
            freePath(path);
            break;
        }
        exportPathShort(shortPathInfo, path); //record stats on the solution
        //exportPathShort(statFile, path);
        exportPath(path); //export the actual path for future visualization with the matlab tool
        writePath(map, path); //write the solution into the tensor
        freePath(path); //free the path
        if(i == maxIter-1) { //debugging statement
            printf("Maximum Iteration count reached. Monte Carlo exiting.\n");
        }
    }
    resetGlobalIdCounter(); //resets the global id counter after each monte carlo iteration in case multiple are being run
    exportMap(map, tensorOut); //export the final tensor into the file
    fclose(shortPathInfo); //close the stats file
    fclose(tensorOut); //close the tensor export file
    freeMap(map); //free the map
    //clean exit - all memory freed.
}

int main() {
    monteCarloIteration(50, 20, 100);
}